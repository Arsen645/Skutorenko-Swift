import UIKit

extension Int {
    
    var isPositive : Bool {
        self > 0 ? true : false
    }
    
    var isNegative : Bool {
        self < 0 ? true : false
    }
    var falseOrTrue : Bool {    // if zero return false else true
        self == 0 ? false : true
    }
    var length : Int {  //return number of digits in Int
        var count = 0
        var thisNumber = self
        while (thisNumber != 0) {
            count += 1
            thisNumber /= 10
        }
        return count
    }
    func digits (number: Int) -> String {   //if you insert 4 it return first 4 digits
        var commit = 1
        switch number {
        case 1...self.length:
            for _ in number ..< self.length {
                commit *= 10
            }
            var answer = self / commit
            return String(answer)
        case self.length...:
            var answer = String(self) + "..."
            return answer
        default:
            return "error"
        }
    }
    subscript (position: Int) -> Int? {     // get: return digin on position
        get { var len = self.length
            if position >= len || position < 0 {
                return nil
            }
            var answer = self
            
            var commit = 1
            for _ in 1 ..< len { // находим количество символов и возводим в эту степень десятку
                commit *= 10
            }
            for _ in 0 ..< position { // обрезаем все цифры перед нужной позиции
                answer %= commit
                commit /= 10
            }
            answer /= commit    // обрезаем все цифры после нужной позиции (меньшие единици)
            return abs(answer)
        }
        set {       // change digits on position
            if position <= self.length || position >= 0 { //|| newValue > 9
                var len = self.length
                var commit = 1
                for _ in 1 ..< len - position { //fix if position == len or position-len = 1
                    commit *= 10
                }
                var answer = self
                var ostatok = self % commit
                answer /= commit * 10
                answer = answer * 10 + newValue!    //fix if newValue is
                ostatok %= commit
                
                answer *= commit
                answer += ostatok
                self = answer
                
            }
        }
    }
    subscript (firstPosition: Int, lastPosition: Int) -> Int? { ///govnocode, make it more short
        get { var answer = 0    //return digits from firstPosition to Last position
            
            guard firstPosition >= 0, firstPosition < lastPosition, self[lastPosition] != nil else {
                return nil
            }
            answer = self[firstPosition]!
            
            
            for i in firstPosition + 1 ... lastPosition {
                
                if self[i] == nil {
                    return nil
                } else {
                    answer *= 10
                    answer += self[i]!
                }
            }
            
            return answer
        }
        set {   //govnocode fix it! //change digits from firstPosition to lastPosition to newValue
            var commit = 1
            var digits: Int
            var len = self.length
            for _ in 1 ... len - firstPosition { //fix if position == len or position-len = 1
                commit *= 10
            }
            var answer = self
            digits = answer % commit
            answer = answer / commit
            var commit2 = commit
            var commit3 = 1
            for _ in firstPosition ... lastPosition {
                commit2 /= 10
                commit3 *= 10
            }
            newValue
            answer
            answer *= commit3
            answer += newValue!
            digits
            digits %= commit2
            digits
            answer *= commit2
            answer += digits
            self = answer
        }
    }
    subscript (range: Range<Int>) -> Int? {     //get of previous subscript, I did not make set because lazyness
        self[range.lowerBound, range.upperBound]

    }
}

var number = 123456
var digits :Int? = 99



//number[2, 3] = digits
number


//number[1,4] = 8888
number.digits(number: 9)
