import UIKit

struct Student {
    var name: String = "no name"
    var surname: String = "no surname"
    var age: Int = 0
    var averageGrade: Double = 0
    
    init(_ name: String, _ surname: String, _ age: Int, _ average: Double) {
        self.name = name
        self.surname = surname
        self.age = age
        self.averageGrade = average
    }
}
let student1 = Student("Jon", "Snow", 20, 4.3)
let student2 = Student("Sansa", "Stark", 18, 3.5)
let student3 = Student("BRob", "Stark", 20, 4.8)
var group = [Student]()

group.append(student1)
group.append(student2)
group.append(student3)

func GetPrintGroup ( group: [Student] ) {
    for i in 0..<group.count {
        print(i+1, group[i].name, group[i].surname, group[i].age, group[i].averageGrade, terminator: " " )
        print("")
    }
}

func getSorted (group: [Student]) -> [Student]{
    
    group.sorted{
        if $0.surname == $1.surname {
           return $0.name < $1.name
        } else {
           return $0.surname < $1.surname
        }
    }
    
        
    
}
getSorted(group: group)


var teachers = group
teachers[0].name = "Ned"
teachers[0]
group[0]
GetPrintGroup(group: group)
