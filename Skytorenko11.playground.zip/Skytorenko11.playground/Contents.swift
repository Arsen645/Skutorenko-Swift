import UIKit
 /*Get minimum and maximum in massive with function and clossure
 var array = [3,4,1,6,3,23,45,66,7,3]
 
 func getCheck (a: Int?, b: Int) -> Bool {
 return a == nil || a! < b
 
 }
 
 
 
 func getResult (numbers: [Int], check: (Int?, Int) -> Bool) -> Int {
 var a: Int?
 for b in numbers{
 if check(a, b) {
 a = b
 }
 }
 return a ?? 0
 }
 let answer = getResult(numbers: array, check: getCheck)
 */
2
/* Get minimum and maximum character of string with function and clossure
 let array = "eteAteGFDShbfr"


 func getMinimum (strok: String = array, check: (Character?, Character) -> Bool) -> Character{
     var a: Character?
     
     for b in strok {
         if check(a, b){
             a = b
         }
     }
     return a!
 }
 getMinimum {
     return $0 == nil || $0! > $1
 }
 */


