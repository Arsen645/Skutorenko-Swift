import UIKit

var inn = "helloone"

var dict = [Character: Int]()

var i = -1

for letter in inn {
    dict[letter, default: 0] += 1
}

var j = ""
for (key, value) in dict {
    if value == 1 {
        j = String(key)
        break
    }
}
j
dict
var g = 0
for letter in inn {
    if j == String(letter) {
        i = g
        break
    }
    g+=1
}
print(i)
