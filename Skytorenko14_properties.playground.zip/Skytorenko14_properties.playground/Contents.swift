import UIKit
import Foundation
/* creating class student
enum Months {
    case Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec
}
struct dateOfBirth {
    var day: Int
    var month: Months
    var year: Int
    init(_ day: Int, _ month: Months, _ year: Int){
        self.day = day
        self.month = month
        self.year = year
    }
}
class Student {
    var firstName: String {
        didSet {
            let capi = firstName.capitalized
            if firstName != capi{
                firstName = capi
            }
        }
    }
    var lastName: String{
        didSet {
            lastName = lastName.capitalized
        }
    }
    var fullName: String {
        get { return firstName + " " + lastName }
        set { print("To change the fullname, change first name or last name") }
    }
    var birth: dateOfBirth
    var studying: Int {
        get{
            2024 - birth.year - 6
        }
    }
    init (_ firstName: String, _ lastName: String, _ birth: dateOfBirth){
        self.firstName = firstName.capitalized
        self.lastName = lastName.capitalized
        self.birth = birth
    }
}
var studentOne = Student("inAn", "invanov", dateOfBirth(8, Months.Jan, 1999))
studentOne.studying
studentOne.fullName
studentOne.firstName

var name = "nei"
name = name.capitalized
*/

class Point {
    var x = 0.0
    var y = 0.0
    init (_ x: Double, _ y: Double) {
        self.x = x
        self.y = y
        
    }
}
func shiftX (firstPoint: Double, shift: Double) -> Double {
    firstPoint + shift
}
class line {
    var pointA: Point
    var pointB: Point
    
    var midPoint: Point {
        get {
            var A = ((pointA.x + pointB.x)/2)
            var B = ((pointA.y + pointB.y)/2)
            return Point(A, B)
        }
        set {
            
            var xShift = newValue.x - midPoint.x
            var yShift = newValue.y - midPoint.y
            
            pointA.x = shiftX(firstPoint: pointA.x, shift: xShift)
            //pointA.x = pointA.x + xShift
            pointB.x = shiftX(firstPoint: pointB.x, shift: xShift)
            pointA.y = shiftX(firstPoint: pointA.y, shift: yShift)
            pointB.y = shiftX(firstPoint: pointB.y, shift: yShift)
            
        }
    }
    var length: Double {
        get {
            var firstSide = (pointA.x - pointB.x)*(pointA.x - pointB.x)
            var secondSide = (pointA.y - pointB.y)*(pointA.y - pointB.y)
            return sqrt(firstSide + secondSide)
        }
        set {
            var xShift = (length - newValue) * (abs(pointA.x - pointB.x)) / length
            var yShift = (length - newValue) * (abs(pointA.y - pointB.y)) / length

            if newValue > length {
                if pointB.x > pointA.x {
                    pointB.x = pointB.x + abs(xShift)
                } else {
                    pointB.x = pointB.x - abs(xShift)
                }
                if pointB.y > pointA.y {
                    pointB.y = pointB.y + abs(yShift)
                } else {
                    pointB.y = pointB.y - abs(yShift)
                }
            }else {
                    if pointB.x > pointA.x {
                        pointB.x = pointB.x - abs(xShift)
                    } else {
                        pointB.x = pointB.x + abs(xShift)
                    }
                    if pointB.y > pointA.y {
                        pointB.y = pointB.y - abs(yShift)
                    } else {
                        pointB.y = pointB.y + abs(yShift)
                }
            }
        }
//        instead previous IF you could do this set:
//           set{
//                      let ratio = newLength / length
//                      let deltaX = (pointB.x - pointA.x) * ratio
//                      let deltaY = (pointB.y - pointA.y) * ratio
//                      pointB.x = pointA.x + deltaX
//                      pointB.y = pointA.y + deltaY
//        }
        
    }
    init(first: Point, second: Point) {
        pointA = first
        pointB = second
    }

}
var myLine = line(first: Point(8,0), second: Point(0,6))
myLine.length
myLine.length = 14
myLine
