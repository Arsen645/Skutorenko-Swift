import UIKit
// игра где мы можем ходить человечком "()" и двигать коробку "[]". При этом не можем выйти за пределы комнаты
struct Room {
    var width: Int
    var length: Int
}

struct Man {
    var x: Int {
        didSet {
            if x > myRoom.width || x <= 0  {
                x = oldValue
            }
        }
    }
    var y: Int {
        didSet {
            if y > myRoom.width || y <= 0 {
                y = oldValue
            }
        }
    }
    
    
    
        
    mutating func step (x: Int, y: Int) {
        if myBox.x == self.x + x && myBox.y == self.y && (myBox.x < myRoom.width && myBox.x > 1){
            myBox.x += x
            self.x += x
        } else if (myBox.x != self.x + x || myBox.y != self.y) {
            self.x += x
        }
        if (myBox.x == self.x && myBox.y == self.y + y) && (myBox.y < myRoom.length && myBox.y > 1) {
            myBox.y += y
            self.y += y
        } else if (myBox.x != self.x || myBox.y != self.y + y) {
            self.y += y
        }
        
    }
    mutating func goToRight () {
        step(x: 1, y: 0)
    }
    mutating func goDown () {
        step(x: 0, y: 1)
    }
    mutating func goToLeft () {
        step(x: -1, y: 0)
    }
    mutating func goUp () {
        step(x: 0, y: -1)
    }
}
struct Box {
    var x: Int {
        didSet {
            if x > myRoom.width || x < 1 {
                x = oldValue
            }
        }
    }
    var y: Int {
        didSet {
            if y > myRoom.length || y < 1 {
                y = oldValue
            }
        }
    }
}
var man = Man(x: 9, y: 8)
let myRoom = Room(width: 9, length: 9)
var myBox = Box(x: 9, y: 9)
man.goToRight()
man.goUp()
for j in 1 ... myRoom.width {
    for i in 1 ... myRoom.length {
        if i == man.x && j == man.y {
            print("()", terminator: "")
        } else if i == myBox.x && j == myBox.y{
            print("[]", terminator: "")
        } else {
            print("__", terminator: "")
        }
        
    }
    print("")
}
