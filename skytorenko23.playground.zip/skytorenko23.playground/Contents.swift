import UIKit

enum Pets : String {
    case dog = "gav gav", cat = "mur mur", parrot = "sam takoy", tiger = "raw"
}
class Pet {
    let name: String
    let variation: Pets
    func voice () -> () {
        print(variation.rawValue)
    }
    init(name: String, variation: Pets) {
        self.name = name
        self.variation = variation
    }
}


class Human {
    let name: String
    var father: Human?
    var mother: Human?
    var brothers: [Human]?
    var sisters: [Human]?
    var pets: [Pet]?
    
    init (name: String) {
        self.name = name
    }
    
    func setFamily (father: Human, mother: Human, sisters: [Human]?, brothers: [Human]?) {
        
        self.father = father
        self.mother = mother
        self.brothers = brothers
        self.sisters = sisters
        
    }
    func answer(family: [Human]) {
        if let grandDad1 = self.father?.father, let grandDad2 = self.mother?.father,
           let grandMom1 = self.father?.mother, let grandMom2 = self.mother?.mother {
            for member in family {
                if ((member.father === grandDad1) || (member.father === grandDad2)) && member !== self.father && member !== self.mother {
                    if member is Woman {
                        print("\(member.name) is my aunt")
                        continue
                    } else {
                        print("\(member.name) is my uncle")
                        
                        continue
                    }
                    }
                if (member.father?.father === grandDad1 || member.father?.father === grandDad2 || member.mother?.father === grandDad1 || member.mother?.father === grandDad2) && member.father !== self.father {
                    if member is Woman {
                        print("\(member.name) is my cousine")
                        continue
                    } else {
                        print("\(member.name) is my cusen")
                        continue
                    }
                }
                
                if member === grandDad1 || member === grandDad2 {
                    print("\(member.name) is my grandad")
                }
                if member === grandMom1 || member === grandMom2 {
                    print("\(member.name) is my grandmom")
                }
                if member.father === self.father && member !== self {
                    if member is Woman {
                        print("\(member.name) is my sister")
                    } else {
                        print("\(member.name) is my brother")
                    }
                }
                if member === self.father {
                    print("\(member.name) is my father")
                }
                if member === self.mother {
                    print("\(member.name) is my mother")
                }
            }
        }
    }
    
    
    
    
    
}
class Man : Human {
    func move() {
        print("\(self.name) moved the sofa")
    }
}
class Woman : Human {
    func say() {
        print("\(self.name) said something")
    }
}

let alex = Man(name: "Alexander")    // сам человек
let anya = Woman(name: "Ann")          // сестра+

let natalya = Woman(name: "Natalya")   // мать+
let nina = Woman(name: "Nina")         // мать матери (бабушка-2)+
let leonid = Man(name: "Leonid")     // отец матери (дедушка-2)+
let uriy = Man(name: "Juriy")        // брат матери (дядя-1)+
let natalya2 = Woman(name: "Natalya")  // жена дяди

let misha = Man(name: "Mihail")      // сын дяди (дв.брат-2)+
let kate = Woman(name: "Kate")         // дочь дяди (дв.сестра-2)+

let vasya = Man(name: "Vasiliy")     // отец+
let ivan = Man(name: "Ivan")         // отец отца (дедушка-1)+
let galina = Man(name: "Galina")     // мать отца (бабушка-1)+

let lena = Woman(name: "Elena")        // сестра отца (тетя-1)+
let mishaUncle = Man(name: "Mihail") // муж тети
let valeraUncle = Man(name: "Valeriy")    // муж тети

let masha = Woman(name: "Maria")       // дочь тети (дв.сестра-1)+
let dima = Man(name: "Dmitry")       // сын тети (дв.брат-1)+

let olya = Woman(name: "Olga")         // сестра отца (тетя-2)+
let tolya = Man(name: "Tolya")         // сестра отца (тетя-2)
let tanya = Woman(name: "Tatiana")     // дочь тети (дв.сестра-1)+
let alena = Woman(name: "Alena") //+

alex.setFamily(father: vasya, mother: natalya, sisters: [anya], brothers: nil)
anya.setFamily(father: vasya, mother: natalya, sisters: nil, brothers: [alex])

vasya.setFamily(father: ivan, mother: galina, sisters: [olya,lena], brothers: nil)
olya.setFamily(father: ivan, mother: galina, sisters: [lena], brothers: [vasya])
lena.setFamily(father: ivan, mother: galina, sisters: [olya], brothers: [vasya])

natalya.setFamily(father: leonid, mother: nina, sisters: nil, brothers: [uriy])
uriy.setFamily(father: leonid, mother: nina, sisters: [natalya], brothers: nil)

misha.setFamily(father: uriy, mother: natalya2, sisters: [kate], brothers: nil)
kate.setFamily(father: uriy, mother: natalya2, sisters: nil, brothers: [misha])

tanya.setFamily(father: tolya, mother: olya, sisters: [alena], brothers: nil)
alena.setFamily(father: tolya, mother: olya, sisters: [tanya], brothers: nil)
masha.setFamily(father: mishaUncle, mother: lena, sisters: nil, brothers: [dima])
dima.setFamily(father: valeraUncle, mother: lena, sisters: [masha], brothers: nil)
let family : [Human] = [
        alex,anya,
        natalya,nina,leonid,uriy,natalya2,misha,kate,
        vasya,ivan,galina,
        lena,mishaUncle,valeraUncle,masha,dima,
        olya,tolya,tanya,alena
    ]
alex.answer(family: family)
misha.move()

if let man = alex.mother?.brothers[0] as? Man {
    man.move()
}
