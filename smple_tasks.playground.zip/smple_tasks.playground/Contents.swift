import Cocoa

var greeting = "Hello, playground"

func findMax (numbers: [Int]) -> Int {
    var first = numbers[0]
    for number in numbers {
        if number > first {
            first = number
        }
    }
    return first
}
let someArray = [3,46,33,2]
findMax(numbers: someArray)

func isPalenome (word: String) -> Bool {
    let array = Array(word)
    var check = [Character]()
    for ind in stride(from: array.count - 1, through: 0, by: -1) {
        check.append(array[ind])
    }
    if array == check {
        return true
    } else {
        return false
    }
}
var someWord = "nrrjn"
isPalenome(word: someWord)

func sumOfEvens (input: [Int]) -> Int {
    var sum = 0
    for number in input {
        if number % 2 == 0 {
            sum += number
        }
    }
    return sum
}
let getSumm = [1,2,3,4,5,6,7]
sumOfEvens(input: getSumm)
func checkForMulplicity (input: [Int]) -> [String] {
    var answer = [String]()
    for i in 0 ..< input.count {
        switch i {
        case _ where (input[i] % 3 == 0) && (input[i] % 5 == 0) :
            answer.append("FZ")
        case _ where input[i] % 3 == 0:
            answer.append("F")
        case _ where input[i] % 5 == 0:
            answer.append("Z")
        default:
            answer.append(String(input[i]))
        }
    }
    return answer
}
let multiplicy = [1,2,3,4,5,6,6,7,8,8,15]
checkForMulplicity(input: multiplicy)

func characterFrquency (word: String) -> [Character: Int] {
    var answer: [Character: Int] = [:]
    for letter in word {
        answer[letter, default: 0] += 1
    }
    return answer
}
let someName = "library"
characterFrquency(word: someName)

func reverseString (word: String) -> String {
    var answer = word.reversed()
    return String(answer)
}
var toReverse = "hi my friend"
reverseString(word: toReverse)

func getFactorial (input: Int) -> Int {
    var answer = 1
    for number in stride(from: input, to: 1, by: -1) {
        answer *= number
    }
    return answer
}
let fact = 4
getFactorial(input: fact)

//find max with two functions
var array = [-5,-9,-8,2]


let checkTwoNumbers: (Int?, Int) -> Bool = { return $0 == nil || $0! < $1 }
func findMax (input: [Int], check: (Int?, Int) -> Bool) -> Int?{
    var answer: Int?
    for number in input {
        if check(answer, number) {
            answer = number
        }
    }
    return answer
}

findMax(input: array, check: checkTwoNumbers)
