import UIKit
import Foundation
1
//func twoSum(_ nums: [Int], _ target: Int){
//    for i in 0..<nums.count {
//        for j in 0..<nums.count{
//            if nums[i] + nums[j] == target && i != j {
//                print ("\(i) and \(j)")
//            }
//
//        }
//    }
//}
//
//let array = [45,3,2,65,4,3,2,6,1]
//twoSum(array, 7)
2 // 1160 You are given an array of strings words and a string chars.

//class Solution {
//    func countCharacters(_ words: [String], _ chars: String) -> Int {
//    }
//}
3 //1266

//class Solution {
//    func minTimeToVisitAllPoints(_ points: [[Int]]) -> Int {
//        var answer = 0
//        for i in 1..<points.count {
//            let point1 = points[i]
//            let prevP = points[i-1]
//            answer += max(abs(point1[0] - prevP[0]), abs(point1[1] - prevP[1]))
//        }
//        return answer
//    }
//}
/*Хранилище книг: Создайте класс Library, который представляет библиотеку. У этого класса должны быть свойства, такие как books (массив книг), libraryName (название библиотеки) и location (местоположение библиотеки). Реализуйте методы для добавления новых книг, удаления книг и поиска книг по различным критериям
enum TypeOfBook: Int{
    case fiction = 1, reference = 2, scientific = 3
    
    
}
class book {
    let name: String
    let author: String
    let type: TypeOfBook
    
    init(_ bookName: String, _ bookAuthor: String, type: TypeOfBook) {
        name = bookName
        author = bookAuthor
        self.type = type
    }
}


class library {
    var books: [book]
    var name: String
    var location: String
    var numberOfBooks = 0
    func addBook (_ title: String, _ author: String, type: TypeOfBook) {
        let newBook = book(title, author, type: type)
        books.append(newBook)
        numberOfBooks += 1
    }
    func addBook (someBook: book) {
        books.append(someBook)
    }
    
    func removeBook (title: String) {
        if var index = books.firstIndex(where: {$0.name == title}) {
            books.remove(at: index)
            print("removed")
            numberOfBooks -= 1
        } else {
            print("not found")
        }
        
    }
    func findByName (title: String) -> [book] {
        let lookingBook = books.filter( {$0.name == title} )
        return lookingBook
    }
    
    func findByWord (word: String) -> [book] {
        let containsWord = books.filter({$0.name.contains(word)})
        return containsWord
    }
    
    init (_ libraryName: String, _ libraryLocation: String) {
        name = libraryName
        location = libraryLocation
        self.books = []
        
        
    }
}
let kerryLibrary = library("Kerry Library", "Killarney")
let firstBook = book("My Biography", "Lomonosov", type: .reference)
let secondBook = book("My Biography", "Esenin", type: .reference)

kerryLibrary.addBook(someBook: firstBook)
kerryLibrary.addBook(someBook: secondBook)
kerryLibrary.books

let withWord = kerryLibrary.findByWord(word: "My")
print(withWord[0].name, withWord[0].author)
*/
//2 chatgpt
//let NumberOfCharacterInID = 6
//
//class People {
//    let name: String
//    let surname: String
//    init (name: String, surname: String) {
//        self.name = name
//        self.surname = surname
//    }
//}
//struct Transaction {
//    let date: Date
//    let amount: Double
//    let description: String
//}
//struct bankAccount {
//    var balance: Double
//    let accountHolder: People
//    var transactionHistory: [Transaction]
//    var accountNumber: String {
//        didSet {
//            if accountNumber.count != NumberOfCharacterInID {
//                accountNumber = oldValue
//                print("accoun number must consist \(NumberOfCharacterInID) symbols")
//            }
//        }
//    }
//    mutating func insertMoney (_ amount: Double) {
//        balance = balance + amount
//        let description = Transaction(date: Date(), amount: amount, description: "you added \(amount) units. Balance \(balance) units")
//        transactionHistory.append(description)
//        print(description.description)
//    }
//    mutating func withDraw (_ amount: Double) {
//        balance -= amount
//        let description = Transaction(date: Date(), amount: amount, description: "you withdrawed \(amount) units. Balance \(balance) units")
//        transactionHistory.append(description)
//        print(description.description)
//    }
//    func viewHistory () {
//        for i in transactionHistory{
//            print("\(i.date): \(i.description)")
//        }
//    }
//    init (_ balance: Double, _ accountHolder: People, _ accountNumber: String) {
//        self.balance = balance
//        self.accountHolder = accountHolder
//        self.accountNumber = accountNumber
//        transactionHistory = []
//    }
//}
//
//var myAccount = bankAccount(55.30, People(name: "Ars", surname: "inra"), "5tr43e")
//myAccount.insertMoney(87.70)
//myAccount.withDraw(4.5)
//myAccount.viewHistory()
//3
//
//enum TypeOfGood: Int {
//    case food = 1, apparel = 2, furniture = 3, pharmacy = 4
//}
//
//enum Suppliers: String {
//    case jsp = "Jack", uk = "United Kingdom"
//}
//
//class Goods {
//    var name: String
//    var type: TypeOfGood
//    var amount: Int
//    var supplier: Suppliers
//    init (_ name: String, _ type: TypeOfGood, _ amount: Int, _ supplier: Suppliers) {
//        self.name = name
//        self.type = type
//        self.amount = amount
//        self.supplier = supplier
//    }
//}
//
//class store {
//    var inventory: [Goods]
//    let storeName: String
//    let location: String
//    
//    func addProducts (_ name: String, _ type: TypeOfGood, _ amount: Int, _ supplier: Suppliers) {
//        
//        if let existingProductIndex = inventory.firstIndex(where: {$0.name == name}) {
//            inventory[existingProductIndex].amount += amount
//            print("Added \(amount) of \(name). Total amount = \(inventory[existingProductIndex].amount)")
//        } else {
//            let newProduct = Goods(name, type, amount, supplier)
//            inventory.append(newProduct)
//            print("Added new product \(name). Amount = \(amount)")
//        }
//    }
//    func addProducts (product: Goods) {
//        addProducts(product.name, product.type, product.amount, product.supplier)
//    }
//    func saleOfProduct (products: String, amount: Int) {
//        if let existingOfProduct = inventory.firstIndex(where: {$0.name == products}) {
//            if inventory[existingOfProduct].amount >= amount {
//                inventory[existingOfProduct].amount -= amount
//                print("Sold \(amount) of \(products). \(inventory[existingOfProduct].amount) remained")
//            } else {
//                print("Sorry, we are of out \(products). Would you like to buy \(inventory[existingOfProduct].amount) \(products)")
//            }
//        } else {
//            print("Not found \(products) in scope")
//        }
//    }
//    
//    func saleManyProducts (_ products: [String], _ amount: [Int]) {
//        for i in 0 ..< products.count {
//            saleOfProduct(products: products[i], amount: amount[i])
//        }
//    }
//    
//    init (_ name: String, _ location: String) {
//        storeName = name
//        self.location = location
//        inventory = []
//    }
//}
//var myStore = store("book store", "Killarney")
//myStore.addProducts("snickers", .food, 4, .jsp)
//myStore.addProducts("water", .food, 42, .uk)
//myStore.addProducts("snickers", .food, 12, .uk)
//myStore.saleOfProduct(products: "water", amount: 3)
//myStore.saleManyProducts(["water", "snickers"], [3,7])
