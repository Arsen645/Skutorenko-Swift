import UIKit
import Foundation
func getEvenNumbers (numbers: [Int], check: (Int) -> Bool) -> [Int] {
    var answer = [Int]()
    for i in numbers {
        if check(i) {
            answer.append(i)
        }
    }
    return answer
}

let array = [1, 2, 3, 4, 5]

getEvenNumbers(numbers: array) { i in
    if i % 2 != 0 {
        return true
    }
    return false
}
















func getCapitalLetters (word: String, check: (Character) -> Bool) -> String {
    var answer = ""
    for letter in word {
        if check(letter) {
            answer += String(letter)
        }
    }
    return answer
}

let query = "heLlo WOrlD"

getCapitalLetters(word: query) { l in
    if l.isUppercase {
        return true
    }
    return false
}

