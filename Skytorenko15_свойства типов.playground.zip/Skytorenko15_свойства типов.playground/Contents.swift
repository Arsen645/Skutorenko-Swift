import UIKit

let MaxNameLength = 50

enum FileType {
    case hiden, unhided
}

struct fileDescription {
    let wayToTheFold: String
    var name : String {
        didSet {
            if name.count > MaxNameLength {
                name = oldValue
            }
        }
    }
    lazy var maxSize = 32
    let typeOfTheFile: FileType
    var content: String
    var wayToTheFile: String {
        return wayToTheFold + "/" + name
    }

}
