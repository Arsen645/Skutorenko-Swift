import UIKit

class Human {
    var firstName: String
    var secondName: String
    var age: Int
    
    init (firstName: String, secondName: String, age: Int) {
        self.firstName = firstName
        self.secondName = secondName
        self.age = age
    }
    convenience init (firstName: String, age: Int) {
        self.init (firstName: firstName, secondName: "", age: 12)
    }
}

class YongMan : Human {
    
    var weigh: Int
    var hobby: String
    
    init(weigh: Int, hobby: String, firstName: String, secondName: String, age: Int) {
        self.weigh = weigh
        self.hobby = hobby
        super.init(firstName: firstName, secondName: secondName, age: age)
    }
    
}

let jon = Human(firstName: "jon", secondName: "snow", age: 22)
let sansa = Human(firstName: "sanse", age: 23)
