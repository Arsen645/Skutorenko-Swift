import UIKit
extension UInt8 {
    func isA (name: List) -> Bool {
        let answer = self & name.rawValue
        if answer == 0 { return false } else { return true }
    }
    func binary () -> String {
        var result = ""
        for i in 0..<8 {
            let mask = 1 << i
            let set = Int (self) & mask != 0
            result = (set ? "I": "O") + result
        }
        return result
    }
    
}
var greeting = "Hello, playground"

enum List : UInt8 {
    case bread =    0b00000001
    case eggs =     0b00000010
    case chicken =  0b00000100
    case beef =     0b00001000
    case cheese =   0b00010000
}
var check: UInt8 = 0b00001001

check.isA(name: .beef)
var snake: UInt8 = 0b00000001
for _ in 0 ... 2 {
    for _ in 0 ... 6 {
        if (snake << 1) < 246 {
            print(snake.binary())
            snake = snake << 1
        }
    }
    for _ in 0 ... 6 {
        if (snake >> 1) > 0 {
            print(snake.binary())
            snake = snake >> 1
        }
    }
}
