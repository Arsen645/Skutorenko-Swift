import UIKit
import Foundation

//////////////////////////////////////////////////////////////////////////////////////////////////////////// shows is entered cell of chess board white or black
//func color(_ letter: Character, _ number: Int) -> String {
//    var ret = "error"
//    if let answer = letter.utf8.first {
//        if answer % 2 == number % 2 {
//            ret = "Black"
//        } else {
//            ret = "White"
//        }
//    }
//    return ret
//}
//
//let atr = color
//print(atr("A",4))
////////////////////////////////////////////////////////////////////////////////////////////////////////////

// MARK: reverse array or sequency of numbers:
//func reverseArray (someArray numbers: [Int]) -> [Int] {
//    var answer = [Int]()
//    for digit in 0..<numbers.count {
//        answer.insert(numbers[digit], at: 0)
//    }
//    return answer
//}
//func reverseArray (someArray numbers: Int...) -> [Int] {
//    var answer = [Int]()
//    for digit in numbers {
//        answer.insert(digit, at: 0)
//    }
//    return answer
//}
//var row = [1,2,3,4]
//let array = reverseArray(someArray:row)
//print(array)
////////////////////////////////////////////////////////////////////////////////////////////////////////////

// меняем изначальрый массив numbers на другой с помощью сквозного параметра (inout)
//в данном случае мы поменяли массив на такой же но в обратном порядке
//func reverseArray (someArray numbers: inout [Int]) {
//    var answer = [Int]()
//    for digit in 0..<numbers.count {
//        answer.insert(numbers[digit], at: 0)
//    }
//    numbers = answer
//}
// function that remake the string: replace vowels to uppercase

//var word = "Hello, world"
//var count = 0
//
//
//
//func remake (row: String) -> String {
//    var answer = ""
//    for letter in row {
//        switch letter {
//        case "a", "e", "o", "i", "u", "y":
//            answer.append(letter.uppercased())
//        default:
//            answer.append(letter)
//        }
//    }
//    return answer
//}
//remake(row: word)

//func reverse2 (array: Int...) -> [Int] {
//    array.reversed()
//}
//print(reverse2(array: 1,2,4,5))
