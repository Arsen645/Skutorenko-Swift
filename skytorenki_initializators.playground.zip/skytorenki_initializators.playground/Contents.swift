import UIKit

class auto {
    var color: String
    var force: Int
    
    init (color: String, force: Int) {
        self.color = color
        self.force = force
    }
    convenience init (force: Int) {
        self.init(color: "White", force: force)
    }
}

class car : auto {
    var numberOfWheels = 4
    
    convenience init(color: String, force: Int, number: Int) {
        self.init(color: color, force: force)
        numberOfWheels = number
    }
}
class bike : auto {
    var mass = 0
    init(color: String, force: Int, mass: Int) {
        self.mass = mass
        super.init(color: color, force: force)
    }
    override init(color: String, force: Int) {
        super.init(color: color, force: force)
    }
}


