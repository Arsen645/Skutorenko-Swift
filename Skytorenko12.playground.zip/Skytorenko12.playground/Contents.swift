import UIKit
import Foundation
//creating a chess board with figures on it
enum Figure {
    case King(color: Color, row: Row, column: Column)
    case Queen(color: Color, row: Row, column: Column)
    case Knight(color: Color, row: Row, column: Column)
    case Bishop(color: Color, row: Row, column: Column)
    case Rook(color: Color, row: Row, column: Column)
    case Pawn(color: Color, row: Row, column: Column)
    
    enum Color {
        case White, Black
    }
    enum Row : Int {
        case One = 1, Two = 2, Three = 3, Four = 4
        case Five = 5, Six = 6, Seven = 7, Eight = 8
    }
    enum Column : Int {
        case A = 1, B = 2, C = 3, D = 4, E = 5, F = 6, G = 7, H = 8
    }
    
}
var scape = [Figure.King(color: .Black, row: .Eight, column: .H),
                 Figure.Rook(color: .White, row: .One, column: .H),
                 Figure.Queen(color: .White, row: .Seven, column: .G),
                Figure.Pawn(color: .White, row: .One, column: .A),
                Figure.Pawn(color: .White, row: .Five, column: .E),
]

let bishop = Figure.Bishop(color: .White, row: .Five, column: .E)

//func getInformation (_ figure: Figure) {
//    switch figure {
//    case .King(let color, let row, let column):
//        print("King at \(row) \(column) with color \(color)")
//    case .Queen(let color, let row, let column):
//        print("Queen at \(row) \(column) with color \(color)")
//    case .Knight(let color, let row, let column):
//        print("Knight at \(row) \(column) with color \(color)")
//    case .Bishop(let color, let row, let column):
//        print("Bishop at \(row) \(column) with color \(color)")
//    case .Rook(let color, let row, let column):
//        print("Rook at \(row) \(column) with color \(color)")
//    case .Pawn(let color, let row, let column):
//        print("Pawn at \(row) \(column) with color \(color)")
//    }
//}
//getInformation(bishop)
//for i in 0..<scape.count {
//    getInformation(scape[i])
//}
func Landscape (_ figure: [Figure]) {
    for i in 1...8{
        for j in 1...8{
            var flag = 0
            for figure in figure{
                switch figure {
                case .Bishop(_, let row, let column) where
                    (row.rawValue % 2 == column.rawValue % 2) &&
                    (row.rawValue == j && column.rawValue == i):
                    print("\u{2657} ", terminator: "")
                    flag = 1
                case .King(_, let row, let column) where
                    (row.rawValue % 2 == column.rawValue % 2) &&
                    (row.rawValue == j && column.rawValue == i):
                    print("\u{2654} ", terminator: "")
                    flag = 1
                case .Queen(_, let row, let column) where
                    (row.rawValue % 2 == column.rawValue % 2) &&
                    (row.rawValue == j && column.rawValue == i):
                    print("\u{2655} ", terminator: "")
                    flag = 1
                case .Rook(_, let row, let column) where
                    (row.rawValue % 2 == column.rawValue % 2) &&
                    (row.rawValue == j && column.rawValue == i):
                    print("\u{2657} ", terminator: "")
                    flag = 1
                case .Knight(_, let row, let column) where
                    (row.rawValue % 2 == column.rawValue % 2) &&
                    (row.rawValue == j && column.rawValue == i):
                    print("\u{2658} ", terminator: "")
                    flag = 1
                case .Pawn(_, let row, let column) where
                    (row.rawValue % 2 == column.rawValue % 2) &&
                    (row.rawValue == j && column.rawValue == i):
                    print("\u{2659} ", terminator: "")
                    flag = 1
                default: break
                }
                
            }
            if flag == 0{
                if (i + j) % 2 == 0 {
                    print("\u{25A1} ", terminator: "")
                } else{
                    print("\u{25A0} ", terminator: "")
                }
                if j == 8 {
                    print("")
                }
            } else {
                flag = 0
            }
        }
    }
    
}
Landscape(scape)

