import UIKit
import Foundation
class Point {
    var x: Int
    var y: Int
    init (x: Int, y: Int) {
        self.x = x
        self.y = y
    }
}

var p1 = Point(x: 2, y: 3)
var p2 = Point(x: 3, y: 5)

func + (a: Point, b: Point) -> Point {
    return Point(x: a.x + b.x, y: a.y + b.y)
}
p1 + p2

func - (a: Point, b: Point) -> Point {
    Point(x: a.x - b.x, y: a.y - b.y)
}

postfix operator --

postfix func -- ( a: inout Point) -> Point {
    var b = a
    a.x = a.x - 1
    a.y = a.y - 1
    return b
}
p1--
p1
prefix operator --
prefix func -- (a: inout Point) {
    a.x = a.x - 1
    a.y = a.y - 1
}
class Size {
    var widthX: Int
    var lengthY: Int
    init(width: Int, length: Int) {
        self.widthX = width
        self.lengthY = length
    }
}
class Rectangle {
    var point: Point
    var size: Size
    init (x: Int, y: Int, width: Int, length: Int) {
        self.point = Point(x: x, y: y)
        self.size = Size(width: width, length: length)
    }
}
let firstRectangle = Rectangle(x: 2, y: 2, width: 3, length: 3)
let secondRectangle = Rectangle(x: 9, y: 9, width: 1, length: 1)

func + (firstRect: Rectangle, secondRect: Rectangle) -> Rectangle{
    var finalWidth = firstRect.size.widthX + secondRect.size.widthX
    var finalLength = firstRect.size.lengthY + secondRect.size.lengthY
    var finalRect = Rectangle(x: firstRect.point.x, y: firstRect.point.y, width: finalWidth, length: finalLength)
    return finalRect
}
firstRectangle + secondRectangle

func += (word: String, number: Int) -> String {
    word + String(number)
}

"hi" += 3

func -= ( word: inout String, letter: Character) {
    var answerWord = ""
    for lett in word {
        if lett != letter {
            answerWord = answerWord + String(lett)
        }
    }
    word = answerWord
    
}

var word = "Hello world"
var someAnswer = ""
var word2 = "hi snow"
for (letter, letter2) in zip( word, word2) {
    if letter == letter2 {
        someAnswer = someAnswer + letter.uppercased()
    } else {
        someAnswer = someAnswer + String(letter)
    }
}
someAnswer

