import UIKit

enum Color {
    case white, black
}

struct chessBoard {
    var board = Array(repeating: Array(repeating: "", count: 8), count: 8)
    
    init () {
        board = Array(repeating: Array(repeating: "", count: 8), count: 8)
    }
    
    mutating func getStartBord () {
        
        self.board[0] = ["♜", "♞", "♝", "♛", "♚", "♝", "♞", "♜"]
        self.board[1] = Array(repeating: "♟", count: 8)
        for i in 2 ..< 6 {
            for j in 0 ..< 8 {
                if j % 2 == i % 2 {
                    self.board[i][j] = "-"
                }else {
                    self.board[i][j] = "_"
                }
            }
        }
        self.board[6] = Array(repeating: "♟", count: 8)
        self.board[7] = ["♜", "♞", "♝", "♛", "♚", "♝", "♞", "♜"]
        
    }
    subscript (row: Int, column: Int) -> Color? {
        get {
            print(board[row - 1][column - 1])
            if row > 9 || column > 8 || row < 1 || column < 1 {
                return nil
            }
            if row % 2 == column % 2 {
                return .white
            } else {
                return .black
            }
        }
    }
    
}

var myBoard = chessBoard()
myBoard.getStartBord()
for i in 0 ..< 8 {
    for j in 0 ..< 8 {
        print(myBoard.board[i][j], terminator: "")
    }
    print("")
}
myBoard[1,6]
